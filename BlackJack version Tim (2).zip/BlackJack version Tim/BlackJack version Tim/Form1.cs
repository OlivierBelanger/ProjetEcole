﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace BlackJack_version_Tim
{
    public partial class Form1 : Form
    {
        const int NBCARTES = 52;
        const int HANDMAX = 11;
        #region DefaultDeck
        string[] DefaultDeck = new string[NBCARTES] {"as_trefle", "_2_trefle",
            "_3_trefle", "_4_trefle", "_5_trefle", "_6_trefle", "_7_trefle",
            "_8_trefle", "_9_trefle", "_10_trefle", "valet_trefle","reine_trefle", "roi_trefle",
            "as_pique", "_2_pique", "_3_pique","_4_pique", "_5_pique", "_6_pique", "_7_pique",
            "_8_pique", "_9_pique", "_10_pique","valet_pique", "reine_pique", "roi_pique",
            "as_coeur","_2_coeur","_3_coeur","_4_coeur","_5_coeur","_6_coeur","_7_coeur",
            "_8_coeur","_9_coeur","_10_coeur","valet_coeur","reine_coeur","roi_coeur",
            "as_carreau","_2_carreau","_3_carreau","_4_carreau","_5_carreau","_6_carreau","_7_carreau",
            "_8_carreau","_9_carreau","_10_carreau","valet_carreau","reine_carreau","roi_carreau"};
        #endregion
        int[] ValueCard = new int[NBCARTES / 4] { 11, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13 };

        string[] Deck = new string[NBCARTES];

        string[] HandPlayerOne = new string[HANDMAX];
        string[] HandPlayerTwo = new string[HANDMAX];

        Random rnd = new Random();

        int NbTour { get; set; }
        int NbCartesRestantes { get; set; }

        int ScorePlayerOne = 0;
        int ScorePlayerTwo = 0;

        bool AIPickTurn = false; // Pour savoir c'est à qui de piger

        public Form1()
        {
            NbCartesRestantes = NBCARTES;
            NbTour = 0;
            Deck = DefaultDeck;
            InitializeComponent();
            Shuffle();
            do
            {
                PickCard(HandPlayerOne);
                PickCard(HandPlayerTwo);
                NbTour++;
            } while (CalculateScore(HandPlayerOne) < 21 && CalculateScore(HandPlayerTwo) < 21);

        }
        /// <summary>
        /// Mélange le paquet de carte
        /// </summary>
        void Shuffle()
        {
            string[] Temp = new string[NBCARTES];
            int position;

            for (int i = 0; i < 52; i++)
            {
                position = rnd.Next(0, NBCARTES);
                if (Temp[position] == null)
                {
                    Temp[position] = Deck[i];
                }
                else
                {
                    i--;
                }
            }

            Deck = Temp;
        }

        /// <summary>
        /// Fais piger une carte aux 2 joueurs 
        /// </summary>
        /// <param name="nbTour">Le tour courant (0 étant le premier)</param>
        void PickCard(string[] playerHand)
        {
            if (AIchoice(NbTour, playerHand))
            {
                if (NbTour < HANDMAX)
                {
                    playerHand[NbTour] = Deck[NbCartesRestantes - 1];
                    NbCartesRestantes--;

                    if (AIPickTurn) // si c'est un AI qui joue
                    {

                        if (playerHand[NbTour].Substring(0, 2) == "as")
                            ScorePlayerOne = ScorePlayerOne + DecideValueOfAs();
                        else
                            CalculateScore(playerHand);
                    }
                    else // si c'est un player
                    {
                        if (playerHand[NbTour].Substring(0, 2) == "as")
                            ScorePlayerTwo = ScorePlayerTwo + CB_Choix.Value;
                        else
                            CalculateScore(playerHand);
                    }
                }
            }

            AIPickTurn = !AIPickTurn; // décide à qui le tour
        }

        void CalculateScore(string[] playerHand)
        {
            int position;
            int somme = 0;
            if (AIPickTurn)
            {
                somme = ScorePlayerOne;
            }
            else
            {
                somme = ScorePlayerTwo;
            }

            position = Array.FindIndex(DefaultDeck, t => t == playerHand[NbTour]);
            position = position % 13;
            somme += ValueCard[position++];
            
            if (AIPickTurn)
            {
                ScorePlayerOne += somme;
            }
            else
            {
                ScorePlayerTwo += somme;
            }
        }

        int CalculateScoreForAI(string[] playerHand, string Card)
        {
            int position;
            int somme = 0;

            bool CardIsAs = Card.Substring(0, 2) == "as";

            if (!CardIsAs)
            {
                position = Array.FindIndex(DefaultDeck, t => t == Card);
                position = position % 13;
                somme = ScorePlayerOne + ValueCard[position++];
            }

            if (CardIsAs)
            {
                somme = ScorePlayerOne + DecideValueOfAs();
            }

            return somme;
        }

        bool AIchoice(int nbTour, string[] playerHand)
        {
            int NbCartesValides = 0; // Nombre de cartes qui lui font pas dépasser 21

            // Essaye toutes les cartes restantes du packet une par une pi check si tu dépasseras 21 ou pas
            for (int i = 0; i < NbCartesRestantes; i++)
            {
                if (CalculateScoreForAI(playerHand, Deck[i]) < 21) // c'est chill tu dépasserais pas 21 avec la carte x restante dans le paquet
                {
                    NbCartesValides++;
                }
            }

            float probabilite = (NbCartesValides / NbCartesRestantes) * 100; // probabilité que la prochaine carte pigée lui fasse dépasser 21

            return probabilite <= difficulty; // return false si le AI refuse de piger
        }

        void EmptyPlayerHand()
        {
            Array.Clear(HandPlayerOne, 0, HandPlayerOne.Length);
            Array.Clear(HandPlayerTwo, 0, HandPlayerTwo.Length);
        }

        int DecideValueOfAs()
        {
            if (ScorePlayerOne > 10)
            {
                return 1;
            }
            else
            {
                return 11;
            }
        }
    }
}
