﻿namespace BlackJack
{
    partial class PlayGame
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.BTN_Play = new System.Windows.Forms.Button();
            this.BTN_Quit = new System.Windows.Forms.Button();
            this.RB_JVSIA = new System.Windows.Forms.RadioButton();
            this.RB_IAVSIA = new System.Windows.Forms.RadioButton();
            this.RB_Easy = new System.Windows.Forms.RadioButton();
            this.RB_Medium = new System.Windows.Forms.RadioButton();
            this.RB_Hard = new System.Windows.Forms.RadioButton();
            this.GB_Difficulty = new System.Windows.Forms.GroupBox();
            this.GB_Difficulty.SuspendLayout();
            this.SuspendLayout();
            // 
            // BTN_Play
            // 
            this.BTN_Play.DialogResult = System.Windows.Forms.DialogResult.OK;
            this.BTN_Play.Location = new System.Drawing.Point(12, 12);
            this.BTN_Play.Name = "BTN_Play";
            this.BTN_Play.Size = new System.Drawing.Size(139, 88);
            this.BTN_Play.TabIndex = 0;
            this.BTN_Play.Text = "Play";
            this.BTN_Play.UseVisualStyleBackColor = true;
            // 
            // BTN_Quit
            // 
            this.BTN_Quit.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.BTN_Quit.Location = new System.Drawing.Point(157, 12);
            this.BTN_Quit.Name = "BTN_Quit";
            this.BTN_Quit.Size = new System.Drawing.Size(139, 88);
            this.BTN_Quit.TabIndex = 1;
            this.BTN_Quit.Text = "Quit";
            this.BTN_Quit.UseVisualStyleBackColor = true;
            // 
            // RB_JVSIA
            // 
            this.RB_JVSIA.AutoSize = true;
            this.RB_JVSIA.Location = new System.Drawing.Point(27, 122);
            this.RB_JVSIA.Name = "RB_JVSIA";
            this.RB_JVSIA.Size = new System.Drawing.Size(101, 17);
            this.RB_JVSIA.TabIndex = 2;
            this.RB_JVSIA.TabStop = true;
            this.RB_JVSIA.Text = "Player versus AI";
            this.RB_JVSIA.UseVisualStyleBackColor = true;
            this.RB_JVSIA.CheckedChanged += new System.EventHandler(this.Player_AI_CheckedChanged);
            // 
            // RB_IAVSIA
            // 
            this.RB_IAVSIA.AutoSize = true;
            this.RB_IAVSIA.Location = new System.Drawing.Point(182, 122);
            this.RB_IAVSIA.Name = "RB_IAVSIA";
            this.RB_IAVSIA.Size = new System.Drawing.Size(82, 17);
            this.RB_IAVSIA.TabIndex = 3;
            this.RB_IAVSIA.TabStop = true;
            this.RB_IAVSIA.Text = "AI versus AI";
            this.RB_IAVSIA.UseVisualStyleBackColor = true;
            this.RB_IAVSIA.CheckedChanged += new System.EventHandler(this.Player_AI_CheckedChanged);
            // 
            // RB_Easy
            // 
            this.RB_Easy.AutoSize = true;
            this.RB_Easy.Location = new System.Drawing.Point(6, 19);
            this.RB_Easy.Name = "RB_Easy";
            this.RB_Easy.Size = new System.Drawing.Size(48, 17);
            this.RB_Easy.TabIndex = 4;
            this.RB_Easy.TabStop = true;
            this.RB_Easy.Text = "Easy";
            this.RB_Easy.UseVisualStyleBackColor = true;
            this.RB_Easy.CheckedChanged += new System.EventHandler(this.AI_Difficulty_CheckedChanged);
            // 
            // RB_Medium
            // 
            this.RB_Medium.AutoSize = true;
            this.RB_Medium.Location = new System.Drawing.Point(6, 42);
            this.RB_Medium.Name = "RB_Medium";
            this.RB_Medium.Size = new System.Drawing.Size(62, 17);
            this.RB_Medium.TabIndex = 5;
            this.RB_Medium.TabStop = true;
            this.RB_Medium.Text = "Medium";
            this.RB_Medium.UseVisualStyleBackColor = true;
            this.RB_Medium.CheckedChanged += new System.EventHandler(this.AI_Difficulty_CheckedChanged);
            // 
            // RB_Hard
            // 
            this.RB_Hard.AutoSize = true;
            this.RB_Hard.Location = new System.Drawing.Point(6, 65);
            this.RB_Hard.Name = "RB_Hard";
            this.RB_Hard.Size = new System.Drawing.Size(48, 17);
            this.RB_Hard.TabIndex = 6;
            this.RB_Hard.TabStop = true;
            this.RB_Hard.Text = "Hard";
            this.RB_Hard.UseVisualStyleBackColor = true;
            this.RB_Hard.CheckedChanged += new System.EventHandler(this.AI_Difficulty_CheckedChanged);
            // 
            // GB_Difficulty
            // 
            this.GB_Difficulty.Controls.Add(this.RB_Easy);
            this.GB_Difficulty.Controls.Add(this.RB_Hard);
            this.GB_Difficulty.Controls.Add(this.RB_Medium);
            this.GB_Difficulty.Location = new System.Drawing.Point(115, 145);
            this.GB_Difficulty.Name = "GB_Difficulty";
            this.GB_Difficulty.Size = new System.Drawing.Size(82, 87);
            this.GB_Difficulty.TabIndex = 7;
            this.GB_Difficulty.TabStop = false;
            this.GB_Difficulty.Text = "Difficulty";
            // 
            // PlayGame
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(308, 237);
            this.Controls.Add(this.GB_Difficulty);
            this.Controls.Add(this.RB_IAVSIA);
            this.Controls.Add(this.RB_JVSIA);
            this.Controls.Add(this.BTN_Quit);
            this.Controls.Add(this.BTN_Play);
            this.Name = "PlayGame";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Begin game";
            this.GB_Difficulty.ResumeLayout(false);
            this.GB_Difficulty.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button BTN_Play;
        private System.Windows.Forms.Button BTN_Quit;
        private System.Windows.Forms.RadioButton RB_JVSIA;
        private System.Windows.Forms.RadioButton RB_IAVSIA;
        private System.Windows.Forms.RadioButton RB_Easy;
        private System.Windows.Forms.RadioButton RB_Medium;
        private System.Windows.Forms.RadioButton RB_Hard;
        private System.Windows.Forms.GroupBox GB_Difficulty;
    }
}