﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace BlackJack
{
    public partial class BlackJackTable : Form
    {
        private bool AI = false;
        private int difficulty;
        private bool passTurn = false;
        private bool WinnerLoser;
        private bool NulGame;
        private bool TwoLoser;
        private bool draw = false;
        const int NBCARTES = 52;
        const int HANDMAX = 11;

        #region DefaultDeck
        string[] DefaultDeck = new string[NBCARTES] {"as_trefle", "_2_trefle",
            "_3_trefle", "_4_trefle", "_5_trefle", "_6_trefle", "_7_trefle",
            "_8_trefle", "_9_trefle", "_10_trefle", "valet_trefle","reine_trefle", "roi_trefle",
            "as_pique", "_2_pique", "_3_pique","_4_pique", "_5_pique", "_6_pique", "_7_pique",
            "_8_pique", "_9_pique", "_10_pique","valet_pique", "reine_pique", "roi_pique",
            "as_coeur","_2_coeur","_3_coeur","_4_coeur","_5_coeur","_6_coeur","_7_coeur",
            "_8_coeur","_9_coeur","_10_coeur","valet_coeur","reine_coeur","roi_coeur",
            "as_carreau","_2_carreau","_3_carreau","_4_carreau","_5_carreau","_6_carreau","_7_carreau",
            "_8_carreau","_9_carreau","_10_carreau","valet_carreau","reine_carreau","roi_carreau"};
        #endregion

        int[] ValueCard = new int[NBCARTES / 4] { 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13 };
        string[] Deck = new string[NBCARTES];
        string[] HandPlayerOne = new string[HANDMAX];
        string[] HandPlayerTwo = new string[HANDMAX];

        Random rnd = new Random();
        int NbTour { get; set; }
        int NbCartesRestantes { get; set; }

        public BlackJackTable()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            CreateGame();
        }

        private void CreateGame()
        {
            PlayGame playgame = new PlayGame();
            if (playgame.ShowDialog() == DialogResult.OK)
            {
                int NbTour = CreateDeck();
                AI = playgame.AI;
                difficulty = playgame.difficulty;
                WinnerLoser = false; NulGame = false; TwoLoser = false; passTurn = false; draw = false;

                if (AI)
                {
                    BTN_Draw.Enabled = false;
                    BTN_Pass.Enabled = false;
                    BeginGame_AI_AI(NbTour);
                }
                else
                {
                    BTN_Draw.Enabled = true;
                    BTN_Pass.Enabled = true;
                    BeginGame_AI_Player(NbTour);
                }
            }
            else
            {
                this.Close();
            }
        }

        private int CreateDeck()
        {
            NbCartesRestantes = NBCARTES;
            Deck = DefaultDeck;
            Shuffle();
            return NbTour = 0;
        }

        private void Shuffle()
        {
            string[] Temp = new string[NBCARTES];
            int position;

            for(int i = 0; i < 52; ++i)
            {
                position = rnd.Next(0, NBCARTES);
                if (Temp[position] == null)
                    Temp[position] = Deck[i];
                else
                    i--;

                Deck = Temp;
            }
        }

        private void BeginGame_AI_AI(int NbTour)
        {
            while (WinGame() == true)
            {
                if (!passTurn)
                    BeginTurn_AI(NbTour, 1);
                if (!passTurn)
                    BeginTurn_AI(NbTour, 2);
            }
        }

        private void BeginGame_AI_Player(int NbTour)
        {
            while (WinGame() == true)
            {
                if (!passTurn)
                    BeginTurn_AI(NbTour, 1);
                if (!passTurn)
                    BeginTurn_Player(NbTour);
            }
        }

        private void BeginTurn_AI(int NbTour, int AIType)
        {
            System.Threading.Thread.Sleep(1000);

            bool drawAI;
            if (AIType == 1)
            {
                if ((drawAI = AIChoice(NbTour, 1)) == true)
                    DrawCard(NbTour, HandPlayerOne);
                else
                    passTurn = true;
            }
            else
            {
                if ((drawAI = AIChoice(NbTour, 2)) == true)
                    DrawCard(NbTour, HandPlayerTwo);
                else
                    passTurn = true;
            }
        }

        private void BeginTurn_Player(int NbTour)
        {
            if (draw)
            {
                DrawCard(NbTour, HandPlayerTwo);
            }
        }

        private bool AIChoice(int NbTour, int AIType)
        {
            int score;
            bool pickCard = false;

            if (AIType == 1)
            {
                score = CalculateScore(HandPlayerOne);
                pickCard = CalculateChoice(NbTour, HandPlayerOne);
            }
            else
            {
                score = CalculateScore(HandPlayerTwo);
                pickCard = CalculateChoice(NbTour, HandPlayerTwo);
            }

            return pickCard;
        }

        private bool CalculateChoice(int NbTour, string[] playerHand)
        {
            int NbAs = 0;
            int NbCartesValides = 0;

            for(int i = 0; i < NbTour; ++i)
            {
                if (playerHand[i].Substring(0, 2) == "as")
                    NbAs++;
            }

            for(int i = 0; i < Deck.Length; ++i)
            {
                if (CalculateScore(playerHand, Deck[i], NbAs) < 21)
                    NbCartesValides++;
            }

            float probabilite = (NbCartesValides / Deck.Length) * 100;

            return probabilite <= difficulty;
        }

        private int CalculateScore(string[] playerHand)
        {
            string temp;
            int position;
            int somme = 0;
        }

        private int CalculateScore(string[] playerHand, string Card, int NbAs)
        {

        }

        private void DrawCard(int nbTour, string[] playerHand)
        {
            if(NbTour < HANDMAX)
            {
                playerHand[nbTour] = Deck[NbCartesRestantes - 1];
                NbCartesRestantes--;
            }
        }

        private void BTN_Pass_Click(object sender, EventArgs e)
        {
            passTurn = true;
        }

        private void BTN_Draw_Click(object sender, EventArgs e)
        {
            draw = true;
        }

        private bool WinGame()
        {
            if (WinnerLoser || NulGame || TwoLoser)
                return true;
            else
                return false;
        }
    }
}
