﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace BlackJack
{
    public partial class BlackJackTable : Form
    {
        private bool AI = false;
        private int difficulty;
        private bool passTurn = false;
        private bool WinnerLoser;
        private bool NulGame;
        private bool TwoLoser;
        private bool draw = false;

        public BlackJackTable()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            CreateGame();
        }

        private void CreateGame()
        {
            PlayGame playgame = new PlayGame();
            if (playgame.ShowDialog() == DialogResult.OK)
            {
                AI = playgame.AI;
                difficulty = playgame.difficulty;
                WinnerLoser = false; NulGame = false; TwoLoser = false; passTurn = false; draw = false;

                if (AI)
                {
                    BTN_Draw.Enabled = false;
                    BTN_Pass.Enabled = false;
                    BeginGame_AI_AI();
                }
                else
                {
                    BTN_Draw.Enabled = true;
                    BTN_Pass.Enabled = true;
                    BeginGame_AI_Player();
                }
            }
            else
            {
                this.Close();
            }
        }

        private void BeginGame_AI_AI()
        {
            while (WinGame() != true)
             {
                if (!passTurn)
                    BeginTurn_AI(1);
                if (!passTurn)
                    BeginTurn_AI(2);
             }
        }

        private void BeginGame_AI_Player()
        {
            while (WinGame() != true)
            {
                if(!passTurn)
                    BeginTurn_AI(1);
                if(!passTurn)
                    BeginTurn_Player();
            }
        }

        private void BeginTurn_AI(int numberAI)
        {
            System.Threading.Thread.Sleep(1000);

            if(numberAI == 1)
            {

            }
            else
            {

            }
        }

        private void BeginTurn_Player()
        {
            if(draw)
            {
                //DrawCard();
            }
        }

         private void BTN_Pass_Click(object sender, EventArgs e)
        {
            passTurn = true;
        }

        private void BTN_Draw_Click(object sender, EventArgs e)
        {
            draw = true;
        }

        private bool WinGame()
        {
            if (WinnerLoser || NulGame || TwoLoser)
                return true;
            else
                return false;
        }
    }
}
