﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace BlackJack
{
    public partial class PlayGame : Form
    {
        public bool AI = false;
        public int easy = 30;
        public int medium = 60;
        public int hard = 85;
        public int difficulty = -1;

        public PlayGame()
        {
            InitializeComponent();
            BTN_Play.Enabled = false;
            GB_Difficulty.Enabled = false;
        }

        private void Player_AI_CheckedChanged(object sender, EventArgs e)
        {
            if(RB_IAVSIA.Checked)
                AI = true;

            if(RB_JVSIA.Checked)
                AI = false;

            GB_Difficulty.Enabled = true;
        }

        private void AI_Difficulty_CheckedChanged(object sender, EventArgs e)
        {
            if (RB_Easy.Checked)
                difficulty = easy;
            if (RB_Medium.Checked)
                difficulty = medium;
            if (RB_Hard.Checked)
                difficulty = hard;

            BTN_Play.Enabled = true;
        }
    }
}
